"""
Presentation layer — NiceGUI pages and panels.
"""
