"""
BLE infrastructure layer — device connection, commands and events.
"""
