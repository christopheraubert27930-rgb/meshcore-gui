"""
MeshCore GUI — Threaded BLE Edition.

A graphical user interface for MeshCore mesh network devices,
communicating via Bluetooth Low Energy (BLE).
"""

__version__ = "5.0"
